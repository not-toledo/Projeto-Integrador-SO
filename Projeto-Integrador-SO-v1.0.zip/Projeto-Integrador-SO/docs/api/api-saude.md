# API de Health Check (Módulo B)

`GET http://127.0.0.1:8080/api/health-check`

Cada chamada faz uma nova coleta e avalia os indicadores disponíveis. O módulo **apenas informa**: não altera
configurações, não executa reparos e não faz testes de estresse. O backend escuta somente em `127.0.0.1`.

## Estrutura da resposta

| Campo | Descrição |
|---|---|
| `collectedAt` | Horário da avaliação (UTC, ISO-8601). |
| `source` | Origem dos dados (coleta local via OSHI, sem simulação). |
| `overall` | Maior severidade entre os alertas: `INFO`, `WARNING` ou `CRITICAL`. |
| `infoCount`, `warningCount`, `criticalCount` | Quantidade de alertas por severidade. |
| `thresholds` / `thresholdsSource` | Limites usados e a origem deles. |
| `alerts` | Lista de alertas, do mais grave para o menos grave. |

## Alerta

| Campo | Descrição |
|---|---|
| `id` | Identificador estável (`temperature:cpu`, `disk-space:<volume>`, `memory:usage`, `smart`, `collection:<componente>`). |
| `component` | Componente avaliado. |
| `severity` | `INFO` (Informação), `WARNING` (Atenção) ou `CRITICAL` (Crítico). |
| `kind` | `NORMAL` (dentro do esperado), `PREVENTIVE` (indicador acima do limite; **não prova defeito**) ou `UNAVAILABLE` (dado indisponível; **não é falha física**). |
| `title`, `description` | Resumo e explicação em linguagem simples. |
| `observedValue`, `threshold` | Valor observado e limite aplicado, com unidade (`null` quando não se aplica). |
| `timestamp` | Horário da avaliação. |

## Verificações

| Verificação | Regra |
|---|---|
| Temperatura (CPU) | `>= 95 °C` Crítico; `>= 80 °C` Atenção; senão normal. Sem sensor: Informação / `UNAVAILABLE`. A temperatura nunca é estimada. |
| Espaço em disco | Por volume: espaço livre `< 5%` Crítico; `< 15%` Atenção; senão normal. Mostra espaço livre, total e percentual. Imagens somente leitura (`squashfs`, `iso9660`, `udf`, `cdfs`) são ignoradas. |
| Uso de RAM | `>= 85%` gera **aviso** de uso elevado (Atenção). Nunca é Crítico nem defeito. |
| SMART | **Não suportado na V0.5**: sempre Informação / `UNAVAILABLE`, informando que a saúde física dos discos não foi avaliada. |
| Coleta incompleta | Componentes (SO, CPU, GPU, placa-mãe) sem leitura geram Informação / `UNAVAILABLE`. |

Se uma verificação falhar internamente, vira um alerta informativo (`diagnostic-error:<nome>`) e as demais continuam.

## Origem e configuração dos limites

Os valores padrão são **limites genéricos e conservadores definidos pelo projeto**; não são limites oficiais do
fabricante do seu processador ou disco. Ajuste-os em `backend/src/main/resources/application.properties`:

```
pccheck.health.cpu-temp-warning-c=80
pccheck.health.cpu-temp-critical-c=95
pccheck.health.disk-free-warning-percent=15
pccheck.health.disk-free-critical-percent=5
pccheck.health.ram-used-warning-percent=85
```

Limites incoerentes (por exemplo, crítico menor que atenção) impedem o backend de iniciar, com mensagem explicando o erro.

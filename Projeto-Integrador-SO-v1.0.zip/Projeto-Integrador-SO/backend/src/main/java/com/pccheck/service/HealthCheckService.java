package com.pccheck.service;

import com.pccheck.agent.collector.CollectorRunner;
import com.pccheck.agent.collector.SensorCollector;
import com.pccheck.agent.collector.SystemCollector;
import com.pccheck.agent.lhm.LhmSource;
import com.pccheck.agent.model.CollectorResult;
import com.pccheck.agent.model.SensorInfo;
import com.pccheck.agent.model.SystemSnapshot;
import com.pccheck.diagnostic.HealthEvaluator;
import com.pccheck.diagnostic.HealthInput;
import com.pccheck.diagnostic.HealthReport;
import com.pccheck.diagnostic.HealthThresholds;
import java.time.Instant;
import oshi.SystemInfo;

import org.springframework.stereotype.Service;

/**
 * Coleta os dados reais e executa o Health Check (Módulo B). Inicialização tardia do OSHI, como no
 * inventário: se falhar, o relatório informa dados indisponíveis em vez de impedir o backend de subir.
 */
@Service
public class HealthCheckService {

    private final HealthEvaluator evaluator;
    private final LhmSource lhm;
    private SystemCollector collector;
    private SensorCollector sensorCollector;

    public HealthCheckService(HealthThresholds thresholds, LhmSource lhm) {
        this.evaluator = new HealthEvaluator(thresholds);
        this.lhm = lhm;
    }

    /** Sincronizado para que requisições simultâneas não disparem várias coletas ao mesmo tempo. */
    public synchronized HealthReport check() {
        if (collector == null) {
            try {
                SystemInfo systemInfo = new SystemInfo();
                collector = new SystemCollector(systemInfo);
                sensorCollector = new SensorCollector(systemInfo, lhm);
            } catch (RuntimeException | LinkageError e) {
                collector = null;
                sensorCollector = null;
                SystemSnapshot failed = InventoryService.initializationFailure(e);
                return evaluator.evaluate(new HealthInput(failed,
                        CollectorResult.error("SensorCollector", "Falha ao inicializar a coleta (OSHI).")),
                        Instant.now());
            }
        }
        SystemSnapshot snapshot = collector.collect();
        CollectorResult<SensorInfo> sensors = CollectorRunner.run(sensorCollector);
        return evaluator.evaluate(new HealthInput(snapshot, sensors), Instant.now());
    }
}
